
//////////////////////////////////////////////////////////////////////////////////
/// !!! THIS CODE HAS BEEN WRITTEN BY JUSTCOOL GAMER (FULL CREDITS TO HIM) !!!///
////////////////////////////////////////////////////////////////////////////////
// Création date : 2 February 2024
// Last edit : 4 March 2024
package com.jcd.MemPatcher;

import com.topjohnwu.superuser.Shell;
import com.topjohnwu.superuser.io.SuFile;
import java.util.Set;
import java.nio.file.attribute.PosixFilePermission;
import java.util.HashSet;
import java.nio.file.Files;
import java.io.IOException;
import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import android.content.Context;
import java.util.concurrent.CompletableFuture;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

public class MemPatcher {
    public final static Map<String, List<String>> mods = new HashMap<>();
    private static Context mCtx;
    
    public static void ExecPerm(Context ctx){
        mCtx = ctx;
        CompletableFuture.runAsync(new Runnable() {
    		@Override
    		public void run() {
        		Shell.cmd("chmod 777 /data/local/tmp/MemPatcher").exec();
    		}
		});
    }
    
    public static void Patch(String process, String lib, String hex, String offset){
        final String proc = process;
        final String l = lib;
        final String h = hex;
        final String offs = offset;
        CompletableFuture.runAsync(new Runnable() {
    		@Override
    		public void run() {
        		Shell.cmd("/data/local/tmp/MemPatcher -p " + proc + " -l " + l + " -h '" + h + "' -o " + offs + "").exec();
    		}
		});
    }
    
    public static void PatchSavedMod(String name){
        String process = retrieveRowByName(mods,name).get(0);
        String lib = retrieveRowByName(mods,name).get(1);
        String offset = retrieveRowByName(mods,name).get(2);
        String state = retrieveRowByName(mods,name).get(5);
        String hex="";
       // SketchwareUtil.showMessage(mCtx,state);
        if(state == "f"){
            hex = retrieveRowByName(mods,name).get(3);
            edit(mods,name,5,"t");
        }else{
            hex = retrieveRowByName(mods,name).get(4);
            edit(mods,name,5,"f");
        }
        Patch(process,lib,hex,offset);
    }
    
    public static String Restore_original_hex(String process, String lib, String hex ,String offset){
        Shell.Result result;
        //SketchwareUtil.showMessage(mCtx, "/data/local/tmp/MemPatcher -p " + process + " -l " + lib + " -h '00 00 00 00 00 00 00 00' -o " + offset + " -r hhh");
        result = Shell.cmd("/data/local/tmp/MemPatcher -p " + process + " -l " + lib + " -h '" + hex + " 00' -o " + offset + " -r hhh").exec();
            
        String listString = "";

        for (String s : result.getOut())
        {
        	listString += s;
        }
        return listString;
    }
    
    public static void AddMod(String Name, String process, String lib, String offset, String hex){
        final String n = Name;
        final String proc = process;
        final String l = lib;
        final String h = hex;
        final String offs = offset;
        CompletableFuture.runAsync(new Runnable() {
    		@Override
    		public void run() {
        		String oldh = Restore_original_hex(proc,l,h,offs);
               // String oldh = "00 00 7A 00";
        		addDataWithName(mods, n, proc, l, offs, h, oldh, "f");
    		}
		});
    }
    
    private static void edit(Map<String, List<String>> array, String rowName, int columnIndex, String newData) {
        List<String> row = array.get(rowName);
        if (row != null && columnIndex >= 0 && columnIndex < row.size()) {
            row.set(columnIndex, newData);
        } else {
            System.out.println("Invalid row name or column index.");
        }
    }

    private static List<String> retrieveRowByName(Map<String, List<String>> array, String rowName) {
        return array.get(rowName);
    }

    private static void addDataWithName(Map<String, List<String>> array, String rowName, String column1, String column2, String column3, String column4, String column5, String column6) {
        List<String> row = new ArrayList<>();
        row.add(column1);
        row.add(column2);
        row.add(column3);
        row.add(column4);
        row.add(column5);
        row.add(column6);
        array.put(rowName, row);
    }
    
    public static String floatToLittleEndian(String floatValueString) {
        float floatValue = Float.parseFloat(floatValueString);
        byte[] bytes = ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putFloat(floatValue).array();
        StringBuilder hexString = new StringBuilder();
        for (int i = 0; i < bytes.length; i++) {
            if (i > 0) {
                hexString.append(" ");
            }
            hexString.append(String.format("%02X", bytes[i]));
        }
        return hexString.toString();
    }

    public static String uint32ToLittleEndian(String inputString) {
        long uint32Value = Long.parseLong(inputString);
        StringBuilder stringBuilder = new StringBuilder();
        for (int i = 0; i < 4; i++) {
            stringBuilder.insert(0, String.format("%02X", uint32Value & 0xFF));
            uint32Value >>= 8;
            if (i < 3) {
                stringBuilder.insert(0, " ");
            }
        }
        return stringBuilder.toString();
    }
    
    public static String parseUint32toDWORD(String UINT32){
        String[] arr = UINT32.split(" ");
        
        return arr[3] + " " + arr[2] + " " + arr[1] + " " + arr[0];
    }
    
    public static String hexConverter(String inputString, String type) {
        if (type.equals("FLOAT")) {
            return floatToLittleEndian(inputString);
        }else if (type.equals("DWORD")) {
            return parseUint32toDWORD( uint32ToLittleEndian(inputString));
        }
        return "";
    }
}
